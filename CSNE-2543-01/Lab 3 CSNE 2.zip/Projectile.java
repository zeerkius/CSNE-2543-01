class Projectile
{
/**
 * Determines the angle to shoot a projectile in order
 *  to hit a moving target.
 *

 */


 public static void main(String[] args)
{
int [] Xposition = {5,0,0,5,5,-5,-5,5,-5,0};

 int [] Yposition = {0,5,-5,5,-5,5,-5,0,0,5};

 int [] XVelocity = {1,0,0,1,1,-1,-1,1,0,1};

 int [] YVelocity = {0,1-1,1,-1,1,-1,1,-1,0};
  
 

for (int i = 0; i < Xposition.length; i++)
{
if (Yposition[i] == 0 && YVelocity[i] == 0)
{
   System.out.println("Launch angle " + Math.cos(Xposition[i]/Xposition[i]));
}
if (Xposition[i] == 0 && XVelocity[i] == 0)
{
   System.out.println("Launch angle " + Math.asin(Yposition[i]/Yposition[i]));
}
if ((Xposition[i] > 0 && Yposition[i] > 0) || ( Xposition[i] < 0  && Yposition[i] < 0))
{
   System.out.println("Launch angle " + Math.atan(Xposition[i]/Xposition[i]));
}
if (Xposition[i] < 0 && Yposition[i] > 0)
{
   System.out.println("Lauch angle " + Math.atan(Xposition[i]/Xposition[i]) + Math.asin(Yposition[i]/Yposition[i]));
}
if (Xposition[i] < 0 && YVelocity[i] == 0)
{
   System.out.println("Launch angle " + Math.cos(XVelocity[i]/YVelocity[i]));
}
}

}



}