
public class Divison {

	public static void main(String[] args) {
		float number1 = 7;
	    float number2 = 20;
	    
	    System.out.println("This is the quotient " + number2 / number1);
	    System.out.println("This is the remainder " + number2 % number1);
		
	}

}
