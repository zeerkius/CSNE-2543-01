class Helloworld
{
    public static void main(String args[])
    {
        int count = 1;
        while (count < 101){
            if (count % 3 == 0){
                System.out.println("Fizz");
            }
            if (count % 5 == 0){
                System.out.println("Buzz");
            }
            if (count % 3 == 0 && count % 5 == 0){
                System.out.println("FizzBuzz");
            }
            System.out.println(count);
            count++;

        }
                
            
        
            
    }
}
//file name should be the same as class name