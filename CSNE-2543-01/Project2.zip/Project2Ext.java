import java.util.Scanner;
class Project2Ext
{
    public static void main(String args[])
    {
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter range1 for FizzBuzz");
    int range1 = input.nextInt();
    System.out.println("Enter range2");
    int range2 = input.nextInt();
    System.out.println("Enter divisor 1");
    int div1 = input.nextInt();
    System.out.println("Enter divisor 2");
    int div2 = input.nextInt();
    input.close();
    for (int i = range1 ; i <= range2;i++){
        if (i % div1 == 0){
            System.out.println("Fizz");
        }
        if ( i % div2 == 0){
            System.out.println("Buzz");
        }
        if ( i % div1 == 0 && i % div2 == 0){
            System.out.println("FizzBuzz");
        }
        System.out.println(i);
    } 
    

    }
 
}