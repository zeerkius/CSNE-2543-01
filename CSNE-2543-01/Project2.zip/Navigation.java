
class Navigation{
    public static void main(String args[])
    {
     double sum1 = diffrence(45.0,20.0);
     double sum2 = diffrence(45.0,-45.0);
     double sum3 = diffrence(90.0,-85.0);
     double sum4 = diffrence(90.0,-95.0);
     double sum5 = diffrence(125.0,-45.0);
     double sum6 = diffrence(-88.6381,29.4803);
     double sum7 = diffrence(-159.036,-78.3251);
     double sum8 = diffence(98.0,-56.9);

    public static double diffrence(double bearing , double heading)
    {
    return bearing - heading;
    }
    }

}